public class TrinaryTreeException extends Exception {
	
	public TrinaryTreeException(String errMsg) {
		System.out.println(errMsg);
	}

}
