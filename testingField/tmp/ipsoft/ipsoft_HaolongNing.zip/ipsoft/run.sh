#! /usr/bin/sh
clear
javac Testing.java
java Testing
rm *.class
