public class XMLData extends Data {


	public XMLData() {
		super();
	}




}
