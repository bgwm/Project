#! /usr/bin/sh
clear
javac xml.java
java xml 
rm *.class
